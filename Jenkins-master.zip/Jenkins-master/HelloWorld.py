#! /usr/bin/python3
# This Phython program will print Hellow World...
print("Hello World Demo...Jan 2024...\n")
print("Hello World Demo...Jan 2024...\n")
print("Hello World Demo...Jan 2024...\n")
print("Hello World Demo...Jan 2024...\n")













































